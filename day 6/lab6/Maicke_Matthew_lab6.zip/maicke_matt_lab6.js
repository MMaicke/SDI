//alert("JavaScript works!");

function lab6() {

    var teams = ["bears", "bulls", "cubs", "sox"];

    var colors = ["orange and blue", "red and white", "blue and white", "white and black"];

    for (var i = 0; i < teams.length; i++) {


            console.log("the chicago " + teams[i] + " colors are " + colors[i])




    }
teams.push("fire");
    colors.push("red and blue");

    console.log("the chicago " + teams[i] + " colors are " + colors[i])
}
lab6();